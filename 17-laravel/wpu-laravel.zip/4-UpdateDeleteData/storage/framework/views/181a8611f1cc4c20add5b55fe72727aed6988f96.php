<!-- . bisa di ganti juga dengan slash / sebaliknya ('layout/main') -->


<!-- apapun yang kita tulis di dalam yield disebutnya section -->
<?php $__env->startSection('title', 'About'); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
  <div class="row">
    <div class="col-10">
      <h1 class="mt-3">Hello, <?php echo e($nama); ?>!</h1>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajarcoding\13)laravel\4-UpdateDeleteData\resources\views/about.blade.php ENDPATH**/ ?>