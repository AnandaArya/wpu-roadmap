<!-- . bisa di ganti juga dengan slash / sebaliknya ('layout/main') -->


<!-- apapun yang kita tulis di dalam yield disebutnya section -->
<?php $__env->startSection('title', 'Daftar Kelas'); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
  <div class="row">
    <div class="col-6">
      <h1 class="mt-3">Daftar Kelas</h1>

      <a href="/kelas/create" class="btn btn-primary my-3">Tambah Data Kelas</a>

      <?php if(session('status')): ?>
          <div class="alert alert-success">
              <?php echo e(session('status')); ?>

          </div>
      <?php endif; ?>

      <ul class="list-group">
        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kela): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="list-group-item d-flex justify-content-between align-items-center">
            <?php echo e($kela-> nama); ?>

            <a href="/kelas/<?php echo e($kela->id_kelas); ?>" class="badge badge-info">detail</a>
          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajarcoding\13)laravel\4-UpdateDeleteData\resources\views/kelas/index.blade.php ENDPATH**/ ?>