<!-- . bisa di ganti juga dengan slash / sebaliknya ('layout/main') -->


<!-- apapun yang kita tulis di dalam yield disebutnya section -->
<?php $__env->startSection('title', 'Daftar Kelas'); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
  <div class="row">
    <div class="col-8">
      <h1 class="mt-3">Tambah Data Kelas</h1>

      <form method="POST" action="/kelas">
        <?php echo csrf_field(); ?>`
        <div class="form-group">
          <label for="id_kelas">id_kelas</label>
          <input type="text" class="form-control <?php if ($errors->has('id_kelas')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('id_kelas'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="id_kelas" placeholder="Masukan id_kelas" name="id_kelas" value="<?php echo e(old('id_kelas')); ?>">
          <?php if ($errors->has('id_kelas')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('id_kelas'); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        <div class="form-group">
          <label for="nama">nama</label>
          <input type="text" class="form-control <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="nama" placeholder="Masukan nama" name="nama" value="<?php echo e(old('nama')); ?>">
          <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        <div class="form-group">
          <label for="jumlah_siswa">jumlah_siswa</label>
          <input type="text" class="form-control" id="jumlah_siswa" placeholder="Masukan jumlah_siswa" name="jumlah_siswa" value="<?php echo e(old('jumlah_siswa')); ?>">
        </div>
        <button type="submit" class="btn btn-primary">Tambah Data</button>
      </form>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajarcoding\13)laravel\4-UpdateDeleteData\resources\views/kelas/create.blade.php ENDPATH**/ ?>