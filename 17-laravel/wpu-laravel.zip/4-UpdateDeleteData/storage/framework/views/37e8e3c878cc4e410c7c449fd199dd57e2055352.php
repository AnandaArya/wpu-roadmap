<!-- . bisa di ganti juga dengan slash / sebaliknya ('layout/main') -->


<!-- apapun yang kita tulis di dalam yield disebutnya section -->
<?php $__env->startSection('title', 'Daftar Mahasiswa'); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
  <div class="row">
    <div class="col-8">
      <h1 class="mt-3">Tambah Data Mahasiswa</h1>

      <form method="POST" action="/students">
        <?php echo csrf_field(); ?>
        <div class="form-group">
          <label for="nama">Nama</label>
          <input type="text" class="form-control <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="nama" placeholder="Masukan Nama" name="nama" value="<?php echo e(old('nama')); ?>">
          <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        <div class="form-group">
          <label for="nrp">NRP</label>
          <input type="text" class="form-control <?php if ($errors->has('nrp')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nrp'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="nrp" placeholder="Masukan NRP" name="nrp" value="<?php echo e(old('nrp')); ?>">
          <?php if ($errors->has('nrp')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nrp'); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        <div class="form-group">
          <label for="email">Email</label>
          <input type="text" class="form-control" id="email" placeholder="Masukan Email" name="email" value="<?php echo e(old('email')); ?>">
        </div>
        <div class="form-group">
          <label for="jurusan">Jurusan</label>
          <input type="text" class="form-control" id="jurusan" placeholder="Masukan Jurusan" name="jurusan" value="<?php echo e(old('jurusan')); ?>">
        </div>
        <button type="submit" class="btn btn-primary">Tambah Data</button>
      </form>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajarcoding\13)laravel\4-UpdateDeleteData\resources\views/students/create.blade.php ENDPATH**/ ?>