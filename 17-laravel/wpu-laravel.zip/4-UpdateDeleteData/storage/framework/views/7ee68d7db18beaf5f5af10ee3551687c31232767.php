<!-- . bisa di ganti juga dengan slash / sebaliknya ('layout/main') -->


<!-- apapun yang kita tulis di dalam yield disebutnya section -->
<?php $__env->startSection('title', 'Daftar Kelas'); ?>

<?php $__env->startSection('container'); ?>
<div class="container">
  <div class="row">
    <div class="col-6">
      <h1 class="mt-3">Detail Kelas</h1>

      <?php 
        $cek = var_dump("$kela->nama");
        echo "$cek" . "aa";      
      ?>

        <div class="card">
          <div class="card-body">
              <h5 class="card-text mb-2"><?php echo e($kela->nama); ?>Nama Kelas : XII-RPL-I</h5>
              <h5 class="card-text"><?php echo e($kela->jumlah_siswa); ?>Jumlah Siswa :36  </h5>

              <a href="<?php echo e($kela->id); ?>/edit" type="submit" class="btn btn-primary">Edit</a>
              <form action="/kelas/<?php echo e($kela->id); ?>" method="post" class="d-inline">
                <?php echo method_field('DELETE'); ?> <!-- agar tidak ada orang yang ngetikan di urlnya method delete di jalankan hanya ketika tombolnya di pencet jadi aman beda dengan CI atau PHP native-->
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger">Delete</button>
              </form>
              <a href="/kelas" class="card-link">kembali</>
          </div>
        </div>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\belajarcoding\13)laravel\4-UpdateDeleteData\resources\views/kelas/show.blade.php ENDPATH**/ ?>